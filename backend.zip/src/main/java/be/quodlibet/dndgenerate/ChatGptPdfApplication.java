package be.quodlibet.dndgenerate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatGptPdfApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChatGptPdfApplication.class, args);
    }
}
